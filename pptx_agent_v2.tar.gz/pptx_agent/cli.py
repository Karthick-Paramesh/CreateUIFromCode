#!/usr/bin/env python3
"""
Enterprise PPTX Agent — CLI

Usage:
    python cli.py --topic "Q3 Business Review" --slides 12 --audience "Board"
    python cli.py --topic "Product Roadmap" --tone executive --out ./decks
    python cli.py --topic "Security Posture" --template ./corp_template.pptx

Environment variables (or .env file):
    LLM_PROVIDER  openai | azure | compatible | disabled
    LLM_API_KEY   your key
    LLM_MODEL     gpt-4o
    LLM_BASE_URL  for azure / compatible endpoints
"""
import argparse
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config.settings import load_config, LLMConfig
from src.llm.base import build_llm_client
from src.models import PresentationRequest, GenerationStatus
from src.agent.orchestrator import PresentationOrchestrator
from src.pptx.builder import PresentationBuilder


def parse_args():
    p = argparse.ArgumentParser(description="Enterprise PPTX Agent")
    p.add_argument("--topic",    required=True,  help="Presentation topic / brief")
    p.add_argument("--slides",   type=int, default=10, help="Number of slides (default: 10)")
    p.add_argument("--audience", default="General",   help="Target audience")
    p.add_argument("--tone",     default="professional",
                   choices=["professional", "executive", "technical", "casual"])
    p.add_argument("--lang",     default="en", help="Language code (default: en)")
    p.add_argument("--template", default=None,  help="Path to .pptx template file")
    p.add_argument("--out",      default="./output", help="Output directory")
    p.add_argument("--enrich",   action="store_true",
                   help="Run per-slide enrichment pass (slower, uses more tokens)")
    p.add_argument("--extra",    default="",    help="Extra instructions for the LLM")
    p.add_argument("--verbose",  action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)-8s %(name)s — %(message)s",
    )

    cfg = load_config()

    # Allow CLI --template to override env config
    template_path = args.template or cfg.template_path or None

    llm_client = build_llm_client(cfg.llm.__dict__)
    builder    = PresentationBuilder(template_path=template_path)
    agent      = PresentationOrchestrator(llm_client, builder, enrich_slides=args.enrich)

    request = PresentationRequest(
        topic=args.topic,
        audience=args.audience,
        num_slides=args.slides,
        tone=args.tone,
        language=args.lang,
        extra_instructions=args.extra,
    )

    print(f"\n📊 Generating: '{args.topic}' ({args.slides} slides, tone={args.tone})")
    print(f"   LLM provider : {cfg.llm.provider}")
    print(f"   Template      : {template_path or 'built-in blank'}")
    print(f"   Output dir    : {args.out}\n")

    def on_progress(pct: int, msg: str):
        bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
        print(f"\r  [{bar}] {pct:3d}%  {msg:<55}", end="", flush=True)

    job = agent.run(request, output_dir=args.out, progress_cb=on_progress)
    print()  # newline after progress bar

    if job.status == GenerationStatus.COMPLETE:
        print(f"\n✅ Done — {job.output_path}")
        if job.plan:
            print(f"\nSlide plan ({len(job.plan.slides)} slides):")
            for i, s in enumerate(job.plan.slides, 1):
                print(f"  {i:2d}. [{s.slide_type.value:<16}] {s.title}")
        return 0
    else:
        print(f"\n❌ Failed: {job.error}")
        if args.verbose:
            print("\nFull log:")
            for line in job.log:
                print(" ", line)
        return 1


if __name__ == "__main__":
    sys.exit(main())
