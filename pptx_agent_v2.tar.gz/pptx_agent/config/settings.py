"""
Settings management.

Reads from environment variables or a local .env file.
Provides typed config objects consumed by the rest of the app.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class LLMConfig:
    provider: str = "disabled"          # disabled | openai | azure | compatible
    api_key: str = ""
    model: str = "gpt-4o"
    base_url: str = ""                  # for azure/compatible
    api_version: str = ""               # azure only


@dataclass
class AppConfig:
    output_dir: str = "./output"
    template_path: str = ""            # blank = use bundled default
    enrich_slides: bool = False        # per-slide enrichment (slower, costs more)
    max_slides: int = 30
    llm: LLMConfig = field(default_factory=LLMConfig)


def load_config() -> AppConfig:
    """Load config from environment variables (or .env file if python-dotenv installed)."""
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    llm = LLMConfig(
        provider=os.getenv("LLM_PROVIDER", "disabled"),
        api_key=os.getenv("LLM_API_KEY", os.getenv("OPENAI_API_KEY", "")),
        model=os.getenv("LLM_MODEL", "gpt-4o"),
        base_url=os.getenv("LLM_BASE_URL", ""),
        api_version=os.getenv("LLM_API_VERSION", ""),
    )

    return AppConfig(
        output_dir=os.getenv("OUTPUT_DIR", "./output"),
        template_path=os.getenv("TEMPLATE_PATH", ""),
        enrich_slides=os.getenv("ENRICH_SLIDES", "false").lower() == "true",
        llm=llm,
    )
