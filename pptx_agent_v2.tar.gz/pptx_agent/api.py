"""
FastAPI backend for the Enterprise PPTX Agent React frontend.

Replaces Streamlit. Exposes:
  POST /generate          — SSE stream of progress events
  POST /upload-template   — saves uploaded .pptx, returns path
  GET  /download/{job_id} — download the generated file

Run with:
    uvicorn api:app --reload --port 8000
"""
from __future__ import annotations
import asyncio
import json
import logging
import os
import shutil
import uuid
from pathlib import Path
from typing import AsyncGenerator, Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

import sys
sys.path.insert(0, str(Path(__file__).parent))

from config.settings import load_config
from src.llm.base import build_llm_client
from src.models import (
    GenerationStatus, PresentationRequest,
)
from src.agent.orchestrator import PresentationOrchestrator
from src.pptx.builder import PresentationBuilder

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Enterprise PPTX Agent API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = Path("/tmp/pptx_agent_uploads")
OUTPUT_DIR = Path("./output")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# In-memory job store (use Redis/DB for production)
_jobs: dict[str, dict] = {}


# ─── Request schemas ─────────────────────────────────────────────────────────

class LLMConfig(BaseModel):
    provider: str = "disabled"
    api_key: str = ""
    model: str = "gpt-4o"
    base_url: str = ""
    api_version: str = ""


class GenerateRequest(BaseModel):
    topic: str
    extra_instructions: str = ""
    audience: str = "General"
    num_slides: int = 10
    tone: str = "professional"
    language: str = "en"
    output_dir: str = "./output"
    template_path: Optional[str] = None
    enrich_slides: bool = False
    llm: LLMConfig = LLMConfig()


# ─── SSE helpers ─────────────────────────────────────────────────────────────

def sse(data: dict) -> str:
    return f"data: {json.dumps(data)}\n\n"


async def run_agent_stream(req: GenerateRequest, job_id: str) -> AsyncGenerator[str, None]:
    """Run the agent in a thread pool and stream SSE events."""
    queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_event_loop()

    def progress_cb(pct: int, msg: str):
        loop.call_soon_threadsafe(queue.put_nowait, {"progress": pct, "message": msg})

    def run_sync():
        try:
            llm_client = build_llm_client(req.llm.model_dump())
            builder    = PresentationBuilder(template_path=req.template_path)
            agent      = PresentationOrchestrator(llm_client, builder,
                                                  enrich_slides=req.enrich_slides)
            pptx_req = PresentationRequest(
                topic=req.topic,
                audience=req.audience,
                num_slides=req.num_slides,
                tone=req.tone,
                language=req.language,
                extra_instructions=req.extra_instructions,
                template_path=req.template_path,
            )
            job = agent.run(pptx_req, output_dir=req.output_dir, progress_cb=progress_cb)
            loop.call_soon_threadsafe(queue.put_nowait, {"_job": job})
        except Exception as exc:
            loop.call_soon_threadsafe(queue.put_nowait, {"_error": str(exc)})

    import concurrent.futures
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    future = loop.run_in_executor(executor, run_sync)

    yield sse({"progress": 0, "message": "Starting…"})

    while True:
        try:
            item = await asyncio.wait_for(queue.get(), timeout=120.0)
        except asyncio.TimeoutError:
            yield sse({"error": "Generation timed out"})
            break

        if "_error" in item:
            yield sse({"error": item["_error"], "status": "error"})
            _jobs[job_id] = {"status": "error", "error": item["_error"]}
            break

        if "_job" in item:
            job = item["_job"]
            _jobs[job_id] = {"status": job.status.value, "path": job.output_path}

            if job.status == GenerationStatus.COMPLETE:
                download_url = f"/download/{job_id}"
                filename = Path(job.output_path).name if job.output_path else "presentation.pptx"
                plan_data = None
                if job.plan:
                    plan_data = {
                        "title": job.plan.title,
                        "slides": [
                            {"slide_type": s.slide_type.value, "title": s.title}
                            for s in job.plan.slides
                        ],
                    }
                yield sse({
                    "progress": 100,
                    "message": "Complete",
                    "status": "complete",
                    "plan": plan_data,
                    "download": {"url": download_url, "name": filename},
                })
            else:
                yield sse({"error": job.error or "Unknown error", "status": "error"})
            break

        # Regular progress event
        yield sse(item)

    await future


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.post("/generate")
async def generate(req: GenerateRequest):
    job_id = uuid.uuid4().hex
    return StreamingResponse(
        run_agent_stream(req, job_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@app.post("/upload-template")
async def upload_template(file: UploadFile = File(...)):
    if not file.filename.endswith(".pptx"):
        raise HTTPException(400, "Only .pptx files are accepted")
    dest = UPLOAD_DIR / f"{uuid.uuid4().hex}_{file.filename}"
    with dest.open("wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"path": str(dest)}


@app.get("/download/{job_id}")
async def download(job_id: str):
    job = _jobs.get(job_id)
    if not job or not job.get("path"):
        raise HTTPException(404, "Job not found or still running")
    path = Path(job["path"])
    if not path.exists():
        raise HTTPException(404, "File not found")
    return FileResponse(
        path=str(path),
        filename=path.name,
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
    )


@app.get("/health")
async def health():
    return {"status": "ok"}
