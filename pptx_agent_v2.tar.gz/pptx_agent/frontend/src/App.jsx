import { useState, useRef, useCallback } from "react";

// ─── Design tokens ──────────────────────────────────────────────────────────
// Navy-to-teal gradient brand, slate sidebar, warm-white canvas
const T = {
  navy:       "#1E2761",
  navyMid:    "#2D5A8E",
  teal:       "#0A9396",
  tealLight:  "#94D2BD",
  slate:      "#1E2533",
  slateMid:   "#2A3248",
  slateBorder:"#3D4F6E",
  slateText:  "#DDE3F0",
  canvas:     "#F7F8FA",
  white:      "#FFFFFF",
  textPrim:   "#111827",
  textMuted:  "#6B7280",
  border:     "#E5E7EB",
  green:      "#155724",
  greenBg:    "#D4EDDA",
  amber:      "#856404",
  amberBg:    "#FFF3CD",
  red:        "#721C24",
  redBg:      "#F8D7DA",
  logBg:      "#0D1117",
  logText:    "#C9D1D9",
};

// ─── API client (talks to FastAPI backend) ──────────────────────────────────
const API_BASE = import.meta?.env?.VITE_API_URL ?? "http://localhost:8000";

async function apiGenerate(payload, onProgress) {
  const res = await fetch(`${API_BASE}/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Server error: ${res.status}`);

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop();
    for (const line of lines) {
      if (line.startsWith("data: ")) {
        try { onProgress(JSON.parse(line.slice(6))); } catch {}
      }
    }
  }
}

async function apiUploadTemplate(file) {
  const fd = new FormData();
  fd.append("file", file);
  const res = await fetch(`${API_BASE}/upload-template`, { method: "POST", body: fd });
  if (!res.ok) throw new Error("Upload failed");
  return (await res.json()).path;
}

// ─── Tiny UI primitives ──────────────────────────────────────────────────────
function Label({ children, htmlFor }) {
  return (
    <label htmlFor={htmlFor} style={{ display: "block", fontSize: 12, fontWeight: 600,
      textTransform: "uppercase", letterSpacing: "0.06em", color: T.slateText,
      marginBottom: 6 }}>
      {children}
    </label>
  );
}

function SideInput({ id, label, ...props }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <Label htmlFor={id}>{label}</Label>
      <input id={id} {...props} style={{
        width: "100%", boxSizing: "border-box", padding: "8px 10px",
        background: T.slateMid, border: `1px solid ${T.slateBorder}`,
        borderRadius: 6, color: T.slateText, fontSize: 13,
        outline: "none", ...props.style,
      }} />
    </div>
  );
}

function SideSelect({ id, label, options, ...props }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <Label htmlFor={id}>{label}</Label>
      <select id={id} {...props} style={{
        width: "100%", boxSizing: "border-box", padding: "8px 10px",
        background: T.slateMid, border: `1px solid ${T.slateBorder}`,
        borderRadius: 6, color: T.slateText, fontSize: 13, outline: "none",
      }}>
        {options.map(o => (
          <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
        ))}
      </select>
    </div>
  );
}

function Toggle({ checked, onChange, label, hint }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 16 }}>
      <div onClick={() => onChange(!checked)} style={{
        flexShrink: 0, width: 38, height: 22, borderRadius: 11, cursor: "pointer",
        background: checked ? T.teal : T.slateBorder,
        position: "relative", transition: "background .2s",
      }}>
        <div style={{
          position: "absolute", top: 3, left: checked ? 19 : 3, width: 16, height: 16,
          borderRadius: "50%", background: T.white, transition: "left .2s",
        }} />
      </div>
      <div>
        <div style={{ fontSize: 13, color: T.slateText, fontWeight: 500 }}>{label}</div>
        {hint && <div style={{ fontSize: 11, color: T.textMuted, marginTop: 2 }}>{hint}</div>}
      </div>
    </div>
  );
}

function Badge({ type = "warn", children }) {
  const styles = {
    ok:   { bg: T.greenBg, color: T.green },
    warn: { bg: T.amberBg, color: T.amber },
    err:  { bg: T.redBg,   color: T.red   },
  };
  const s = styles[type] || styles.warn;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 5,
      padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 600,
      background: s.bg, color: s.color }}>
      {children}
    </span>
  );
}

function ProgressBar({ pct }) {
  return (
    <div style={{ height: 6, background: "#E5E7EB", borderRadius: 3, overflow: "hidden" }}>
      <div style={{
        height: "100%", width: `${pct}%`, borderRadius: 3,
        background: `linear-gradient(90deg, ${T.navy}, ${T.teal})`,
        transition: "width .4s ease",
      }} />
    </div>
  );
}

// ─── Slide plan row ──────────────────────────────────────────────────────────
const TYPE_COLOR = {
  title_slide:    { bg: "#EDE9FE", text: "#5B21B6" },
  section_header: { bg: "#DBEAFE", text: "#1E40AF" },
  bullets:        { bg: "#D1FAE5", text: "#065F46" },
  two_column:     { bg: "#FEF3C7", text: "#92400E" },
  table:          { bg: "#FCE7F3", text: "#9D174D" },
  chart:          { bg: "#E0F2FE", text: "#0C4A6E" },
  closing:        { bg: "#F3F4F6", text: "#374151" },
  content:        { bg: "#F0FDF4", text: "#14532D" },
};

function SlideRow({ idx, slide }) {
  const c = TYPE_COLOR[slide.slide_type] || TYPE_COLOR.content;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10,
      padding: "8px 12px", borderBottom: `1px solid ${T.border}` }}>
      <span style={{ fontSize: 12, color: T.textMuted, width: 22, textAlign: "right" }}>
        {idx}
      </span>
      <span style={{ fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 4,
        background: c.bg, color: c.text, whiteSpace: "nowrap" }}>
        {slide.slide_type.replace(/_/g, " ")}
      </span>
      <span style={{ fontSize: 13, color: T.textPrim, flex: 1 }}>{slide.title}</span>
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────────────────────
export default function App() {
  // Config state
  const [provider, setProvider]     = useState("disabled");
  const [apiKey, setApiKey]         = useState("");
  const [model, setModel]           = useState("gpt-4o");
  const [baseUrl, setBaseUrl]       = useState("");
  const [apiVersion, setApiVersion] = useState("2024-02-01");
  const [enrich, setEnrich]         = useState(false);
  const [outputDir, setOutputDir]   = useState("./output");
  const [templatePath, setTemplatePath] = useState("");

  // Brief state
  const [topic, setTopic]     = useState("");
  const [extra, setExtra]     = useState("");
  const [audience, setAudience] = useState("Executive leadership team");
  const [numSlides, setNumSlides] = useState(10);
  const [tone, setTone]       = useState("professional");
  const [language, setLanguage] = useState("en");

  // Generation state
  const [phase, setPhase]     = useState("idle"); // idle | uploading | running | done | error
  const [progress, setProgress] = useState(0);
  const [statusMsg, setStatusMsg] = useState("");
  const [logs, setLogs]       = useState([]);
  const [plan, setPlan]       = useState(null);
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [downloadName, setDownloadName] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [showPlan, setShowPlan] = useState(false);

  const fileRef = useRef();

  const appendLog = useCallback((line) => {
    setLogs(prev => [...prev.slice(-50), line]);
  }, []);

  const handleTemplateUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setPhase("uploading");
    try {
      const path = await apiUploadTemplate(file);
      setTemplatePath(path);
      setPhase("idle");
    } catch (err) {
      setErrorMsg(err.message);
      setPhase("error");
    }
  };

  const handleGenerate = async () => {
    if (!topic.trim()) return;

    setPhase("running");
    setProgress(0);
    setLogs([]);
    setPlan(null);
    setDownloadUrl(null);
    setErrorMsg("");
    setShowPlan(false);

    const payload = {
      topic, extra_instructions: extra,
      audience, num_slides: numSlides,
      tone, language,
      output_dir: outputDir,
      template_path: templatePath || null,
      enrich_slides: enrich,
      llm: { provider, api_key: apiKey, model, base_url: baseUrl, api_version: apiVersion },
    };

    try {
      await apiGenerate(payload, (event) => {
        if (event.progress !== undefined) setProgress(event.progress);
        if (event.message)  { setStatusMsg(event.message); appendLog(`[${event.progress ?? "–"}%] ${event.message}`); }
        if (event.plan)     setPlan(event.plan);
        if (event.download) { setDownloadUrl(event.download.url); setDownloadName(event.download.name); }
        if (event.error)    { setErrorMsg(event.error); setPhase("error"); }
        if (event.status === "complete") setPhase("done");
      });
      if (phase !== "error") setPhase("done");
    } catch (err) {
      setErrorMsg(err.message);
      setPhase("error");
    }
  };

  const isRunning = phase === "running" || phase === "uploading";
  const aiEnabled = provider !== "disabled";

  return (
    <div style={{ display: "flex", minHeight: "100vh", fontFamily: "Inter, system-ui, sans-serif",
      background: T.canvas, color: T.textPrim }}>

      {/* ── Sidebar ── */}
      <aside style={{ width: 280, flexShrink: 0, background: T.slate,
        padding: "28px 20px", display: "flex", flexDirection: "column", gap: 0 }}>

        {/* Logo */}
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: T.white, letterSpacing: "-0.02em" }}>
            PPTX Agent
          </div>
          <div style={{ fontSize: 11, color: T.tealLight, marginTop: 2 }}>
            Enterprise Edition
          </div>
        </div>

        {/* LLM */}
        <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.1em",
          color: T.slateBorder, fontWeight: 700, marginBottom: 12 }}>
          LLM Provider
        </div>
        <SideSelect id="provider" label="Provider" value={provider} onChange={e => setProvider(e.target.value)}
          options={[
            { value: "disabled", label: "Disabled (stub mode)" },
            { value: "openai",   label: "OpenAI" },
            { value: "azure",    label: "Azure OpenAI" },
            { value: "compatible", label: "Compatible endpoint" },
          ]} />

        {aiEnabled && <>
          <SideInput id="apikey" label="API Key" type="password" placeholder="sk-…"
            value={apiKey} onChange={e => setApiKey(e.target.value)} />
          <SideInput id="model" label="Model" value={model}
            onChange={e => setModel(e.target.value)} />
          {(provider === "azure" || provider === "compatible") &&
            <SideInput id="baseurl" label="Endpoint URL" placeholder="https://…"
              value={baseUrl} onChange={e => setBaseUrl(e.target.value)} />}
          {provider === "azure" &&
            <SideInput id="apiver" label="API Version" value={apiVersion}
              onChange={e => setApiVersion(e.target.value)} />}
        </>}

        <div style={{ borderTop: `1px solid ${T.slateBorder}`, margin: "16px 0" }} />

        {/* Template */}
        <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.1em",
          color: T.slateBorder, fontWeight: 700, marginBottom: 12 }}>
          Template
        </div>
        <input ref={fileRef} type="file" accept=".pptx" style={{ display: "none" }}
          onChange={handleTemplateUpload} />
        <button onClick={() => fileRef.current.click()} style={{
          width: "100%", padding: "8px 12px", background: T.slateMid,
          border: `1px solid ${T.slateBorder}`, borderRadius: 6,
          color: T.slateText, fontSize: 12, cursor: "pointer", marginBottom: 8,
          textAlign: "left",
        }}>
          {templatePath
            ? `✓ ${templatePath.split("/").pop()}`
            : "Upload corporate .pptx"}
        </button>
        {templatePath &&
          <button onClick={() => setTemplatePath("")} style={{
            fontSize: 11, color: T.textMuted, background: "none", border: "none",
            cursor: "pointer", padding: "0 0 10px", textAlign: "left",
          }}>Remove template</button>}

        <div style={{ borderTop: `1px solid ${T.slateBorder}`, margin: "8px 0 16px" }} />

        {/* Advanced */}
        <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.1em",
          color: T.slateBorder, fontWeight: 700, marginBottom: 12 }}>
          Advanced
        </div>
        <Toggle checked={enrich} onChange={setEnrich}
          label="Per-slide enrichment"
          hint="Second LLM pass per slide. Slower." />
        <SideInput id="outdir" label="Output directory" value={outputDir}
          onChange={e => setOutputDir(e.target.value)} />

        {/* Status badge */}
        <div style={{ marginTop: "auto", paddingTop: 24 }}>
          {aiEnabled
            ? <Badge type="ok">AI enabled</Badge>
            : <Badge type="warn">Stub mode</Badge>}
        </div>
      </aside>

      {/* ── Main ── */}
      <main style={{ flex: 1, padding: "36px 40px", maxWidth: 900 }}>

        {/* Hero */}
        <div style={{
          background: `linear-gradient(135deg, ${T.navy} 0%, ${T.navyMid} 60%, ${T.teal} 100%)`,
          borderRadius: 14, padding: "32px 36px", marginBottom: 36, color: T.white,
        }}>
          <h1 style={{ margin: "0 0 6px", fontSize: 26, fontWeight: 700, letterSpacing: "-0.02em" }}>
            Enterprise PPTX Agent
          </h1>
          <p style={{ margin: 0, opacity: 0.82, fontSize: 15 }}>
            Generate professional PowerPoint presentations from a topic — AI-powered or in stub mode.
          </p>
        </div>

        {/* Brief + Options grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 28, marginBottom: 28 }}>

          {/* Brief column */}
          <div>
            <h2 style={{ margin: "0 0 16px", fontSize: 14, fontWeight: 700,
              textTransform: "uppercase", letterSpacing: "0.06em", color: T.textMuted }}>
              Presentation Brief
            </h2>

            <div style={{ marginBottom: 14 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 500,
                color: T.textPrim, marginBottom: 6 }}>Topic</label>
              <textarea value={topic} onChange={e => setTopic(e.target.value)}
                rows={4} placeholder="e.g. Q3 2025 Business Review – Sales performance, market headwinds, and Q4 outlook"
                style={{ width: "100%", boxSizing: "border-box", padding: "10px 12px",
                  border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 14,
                  resize: "vertical", outline: "none", fontFamily: "inherit",
                  background: T.white }} />
            </div>

            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 500,
                color: T.textPrim, marginBottom: 6 }}>
                Extra instructions <span style={{ color: T.textMuted, fontWeight: 400 }}>(optional)</span>
              </label>
              <textarea value={extra} onChange={e => setExtra(e.target.value)}
                rows={3} placeholder="e.g. Include a risk matrix slide. Focus on APAC market. Avoid acronyms."
                style={{ width: "100%", boxSizing: "border-box", padding: "10px 12px",
                  border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 14,
                  resize: "vertical", outline: "none", fontFamily: "inherit",
                  background: T.white }} />
            </div>
          </div>

          {/* Options column */}
          <div>
            <h2 style={{ margin: "0 0 16px", fontSize: 14, fontWeight: 700,
              textTransform: "uppercase", letterSpacing: "0.06em", color: T.textMuted }}>
              Options
            </h2>

            {[
              { label: "Target audience", id: "aud", value: audience,
                onChange: e => setAudience(e.target.value), type: "input" },
            ].map(f => (
              <div key={f.id} style={{ marginBottom: 14 }}>
                <label htmlFor={f.id} style={{ display: "block", fontSize: 13, fontWeight: 500,
                  color: T.textPrim, marginBottom: 6 }}>{f.label}</label>
                <input id={f.id} value={f.value} onChange={f.onChange}
                  style={{ width: "100%", boxSizing: "border-box", padding: "8px 12px",
                    border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 14,
                    outline: "none", background: T.white }} />
              </div>
            ))}

            {/* Slide count slider */}
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: "flex", justifyContent: "space-between",
                fontSize: 13, fontWeight: 500, color: T.textPrim, marginBottom: 8 }}>
                <span>Number of slides</span>
                <span style={{ color: T.teal, fontWeight: 700 }}>{numSlides}</span>
              </label>
              <input type="range" min={3} max={30} value={numSlides}
                onChange={e => setNumSlides(Number(e.target.value))}
                style={{ width: "100%", accentColor: T.teal }} />
              <div style={{ display: "flex", justifyContent: "space-between",
                fontSize: 11, color: T.textMuted, marginTop: 2 }}>
                <span>3</span><span>30</span>
              </div>
            </div>

            {[
              { label: "Tone", id: "tone", value: tone, onChange: e => setTone(e.target.value),
                options: ["professional","executive","technical","casual"] },
              { label: "Language", id: "lang", value: language, onChange: e => setLanguage(e.target.value),
                options: [
                  { value: "en", label: "English" }, { value: "de", label: "German" },
                  { value: "fr", label: "French" },  { value: "es", label: "Spanish" },
                  { value: "it", label: "Italian" }, { value: "pt", label: "Portuguese" },
                  { value: "nl", label: "Dutch" },
                ]},
            ].map(f => (
              <div key={f.id} style={{ marginBottom: 14 }}>
                <label htmlFor={f.id} style={{ display: "block", fontSize: 13, fontWeight: 500,
                  color: T.textPrim, marginBottom: 6 }}>{f.label}</label>
                <select id={f.id} value={f.value} onChange={f.onChange} style={{
                  width: "100%", boxSizing: "border-box", padding: "8px 12px",
                  border: `1px solid ${T.border}`, borderRadius: 8, fontSize: 14,
                  outline: "none", background: T.white,
                }}>
                  {f.options.map(o => (
                    <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>

        {/* Generate button */}
        <button onClick={handleGenerate} disabled={isRunning || !topic.trim()}
          style={{
            width: "100%", padding: "14px 24px", borderRadius: 10, border: "none",
            cursor: isRunning || !topic.trim() ? "not-allowed" : "pointer",
            background: isRunning || !topic.trim()
              ? "#9CA3AF"
              : `linear-gradient(135deg, ${T.navy}, ${T.teal})`,
            color: T.white, fontSize: 15, fontWeight: 700,
            letterSpacing: "-0.01em", transition: "opacity .15s",
            opacity: isRunning ? 0.7 : 1,
          }}>
          {isRunning ? "Generating…" : "Generate Presentation"}
        </button>

        {/* ── Progress panel ── */}
        {phase !== "idle" && (
          <div style={{ marginTop: 28, background: T.white, border: `1px solid ${T.border}`,
            borderRadius: 12, overflow: "hidden" }}>

            {/* Header */}
            <div style={{ padding: "14px 20px", borderBottom: `1px solid ${T.border}`,
              display: "flex", alignItems: "center", gap: 10 }}>
              {phase === "done"  && <Badge type="ok">Complete</Badge>}
              {phase === "error" && <Badge type="err">Failed</Badge>}
              {isRunning && <Badge type="warn">Running</Badge>}
              <span style={{ fontSize: 13, color: T.textMuted }}>{statusMsg}</span>
            </div>

            {/* Progress bar */}
            <div style={{ padding: "12px 20px", borderBottom: `1px solid ${T.border}` }}>
              <ProgressBar pct={progress} />
              <div style={{ fontSize: 12, color: T.textMuted, marginTop: 6, textAlign: "right" }}>
                {progress}%
              </div>
            </div>

            {/* Log */}
            <div style={{ background: T.logBg, color: T.logText, fontFamily: "monospace",
              fontSize: 12, padding: "12px 16px", maxHeight: 200, overflowY: "auto" }}>
              {logs.map((l, i) => <div key={i}>{l}</div>)}
            </div>

            {/* Result actions */}
            {phase === "done" && (
              <div style={{ padding: "16px 20px", display: "flex", gap: 12, flexWrap: "wrap" }}>
                {downloadUrl && (
                  <a href={downloadUrl} download={downloadName} style={{
                    padding: "10px 20px", background: T.teal, color: T.white,
                    borderRadius: 8, fontSize: 14, fontWeight: 600, textDecoration: "none",
                  }}>
                    Download .pptx
                  </a>
                )}
                {plan && (
                  <button onClick={() => setShowPlan(p => !p)} style={{
                    padding: "10px 20px", background: T.canvas, border: `1px solid ${T.border}`,
                    borderRadius: 8, fontSize: 14, cursor: "pointer",
                  }}>
                    {showPlan ? "Hide" : "Show"} slide plan ({plan.slides?.length ?? 0} slides)
                  </button>
                )}
              </div>
            )}

            {/* Error */}
            {phase === "error" && (
              <div style={{ padding: "12px 20px", color: T.red, fontSize: 13 }}>
                {errorMsg}
              </div>
            )}
          </div>
        )}

        {/* ── Slide plan ── */}
        {showPlan && plan?.slides && (
          <div style={{ marginTop: 20, background: T.white, border: `1px solid ${T.border}`,
            borderRadius: 12, overflow: "hidden" }}>
            <div style={{ padding: "12px 20px", borderBottom: `1px solid ${T.border}`,
              fontSize: 13, fontWeight: 600 }}>
              {plan.title} — slide plan
            </div>
            {plan.slides.map((s, i) => <SlideRow key={i} idx={i + 1} slide={s} />)}
          </div>
        )}

        {/* Footer */}
        <div style={{ marginTop: 40, paddingTop: 20, borderTop: `1px solid ${T.border}`,
          fontSize: 12, color: T.textMuted }}>
          Enterprise PPTX Agent · runs locally · no data leaves your machine
        </div>
      </main>
    </div>
  );
}
