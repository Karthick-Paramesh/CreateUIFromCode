import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/generate":        "http://localhost:8000",
      "/upload-template": "http://localhost:8000",
      "/download":        "http://localhost:8000",
      "/health":          "http://localhost:8000",
    },
  },
});
