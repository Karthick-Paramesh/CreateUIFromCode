"""
Orchestrator Agent

The top-level controller that sequences:
  1. LLM planning  → PresentationPlan
  2. (Optional) per-slide enrichment
  3. PPTX building → .pptx file

Designed to run either synchronously (for scripts) or to be called
from a Streamlit UI with a progress callback.
"""
from __future__ import annotations
import json
import logging
import uuid
from typing import Callable, Optional

from ..llm.base import LLMClient, StubLLMClient
from ..llm.prompts import SYSTEM_PLANNER, USER_PLANNER
from ..models import (
    GenerationJob, GenerationStatus, PresentationPlan, PresentationRequest,
    SlideContent, BulletPoint, TableData, ChartData, ContentType
)
from ..pptx.builder import PresentationBuilder

logger = logging.getLogger(__name__)

ProgressCallback = Callable[[int, str], None]


class PresentationOrchestrator:
    """
    End-to-end agent for generating a PowerPoint presentation.

    Example:
        agent = PresentationOrchestrator(llm_client, builder)
        job = agent.run(request, output_dir="./output")
        print(job.output_path)
    """

    def __init__(
        self,
        llm_client: LLMClient,
        builder: Optional[PresentationBuilder] = None,
        enrich_slides: bool = False,    # per-slide enrichment pass (slower)
    ):
        self._llm = llm_client
        self._builder = builder or PresentationBuilder()
        self._enrich = enrich_slides

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def run(
        self,
        request: PresentationRequest,
        output_dir: str = "./output",
        progress_cb: Optional[ProgressCallback] = None,
    ) -> GenerationJob:
        """
        Run the full pipeline and return a completed (or failed) GenerationJob.
        """
        job = GenerationJob(
            job_id=uuid.uuid4().hex,
            request=request,
            status=GenerationStatus.IN_PROGRESS,
        )

        def _log(msg: str):
            job.log.append(msg)
            logger.info(msg)

        def _progress(pct: int, msg: str):
            job.progress = pct
            _log(msg)
            if progress_cb:
                progress_cb(pct, msg)

        try:
            # 1. Plan
            _progress(5, "Planning presentation structure…")
            plan = self._plan(request)
            job.plan = plan
            _log(f"Plan: {len(plan.slides)} slides for '{plan.title}'")

            # 2. (Optional) enrich each slide
            if self._enrich and not isinstance(self._llm, StubLLMClient):
                plan = self._enrich_slides(plan, request, _progress)

            # 3. Build PPTX
            def build_progress(pct, msg):
                mapped = 40 + int(pct * 0.60)
                _progress(min(mapped, 100), msg)

            output_path = self._builder.build(
                plan,
                output_dir=output_dir,
                progress_cb=build_progress,
            )

            job.output_path = output_path
            job.status = GenerationStatus.COMPLETE
            job.progress = 100
            _log(f"✓ Presentation saved to {output_path}")

        except Exception as exc:
            logger.exception("Orchestrator failed")
            job.status = GenerationStatus.FAILED
            job.error = str(exc)
            _log(f"✗ Failed: {exc}")

        return job

    # ------------------------------------------------------------------
    # Internal: planning
    # ------------------------------------------------------------------

    def _plan(self, req: PresentationRequest) -> PresentationPlan:
        user_prompt = USER_PLANNER.format(
            topic=req.topic,
            audience=req.audience,
            num_slides=req.num_slides,
            tone=req.tone,
            language=req.language,
            extra_instructions=req.extra_instructions or "None",
        )
        raw = self._llm.complete_json(SYSTEM_PLANNER, user_prompt, temperature=0.7)
        return self._parse_plan(raw)

    def _parse_plan(self, raw: dict) -> PresentationPlan:
        slides = []
        for s in raw.get("slides", []):
            try:
                slide = self._parse_slide(s)
                slides.append(slide)
            except Exception as e:
                logger.warning("Skipping malformed slide: %s – %s", s, e)

        return PresentationPlan(
            title=raw.get("title", "Presentation"),
            subtitle=raw.get("subtitle", ""),
            slides=slides,
        )

    def _parse_slide(self, s: dict) -> SlideContent:
        slide_type_str = s.get("slide_type", "content")
        try:
            slide_type = ContentType(slide_type_str)
        except ValueError:
            slide_type = ContentType.CONTENT

        bullets = [
            BulletPoint(
                text=b.get("text", ""),
                level=b.get("level", 0),
                bold=b.get("bold", False),
            )
            for b in s.get("bullets", [])
        ]

        table = None
        if s.get("table"):
            t = s["table"]
            table = TableData(
                headers=t.get("headers", []),
                rows=t.get("rows", []),
                has_header_row=t.get("has_header_row", True),
            )

        chart = None
        if s.get("chart"):
            c = s["chart"]
            chart = ChartData(
                chart_type=c.get("chart_type", "bar"),
                title=c.get("title", ""),
                categories=c.get("categories", []),
                series=c.get("series", []),
            )

        return SlideContent(
            slide_type=slide_type,
            title=s.get("title", ""),
            subtitle=s.get("subtitle", ""),
            body=s.get("body", ""),
            bullets=bullets,
            left_column=s.get("left_column", ""),
            right_column=s.get("right_column", ""),
            speaker_notes=s.get("speaker_notes", ""),
            table=table,
            chart=chart,
        )

    # ------------------------------------------------------------------
    # Internal: per-slide enrichment (optional second pass)
    # ------------------------------------------------------------------

    def _enrich_slides(
        self, plan: PresentationPlan,
        req: PresentationRequest,
        progress: ProgressCallback,
    ) -> PresentationPlan:
        from ..llm.prompts import SYSTEM_SLIDE_ENRICHER, USER_SLIDE_ENRICHER
        total = len(plan.slides)
        enriched = []
        for i, slide in enumerate(plan.slides):
            pct = 10 + int(25 * i / total)
            progress(pct, f"Enriching slide {i+1}/{total}…")
            try:
                raw = self._llm.complete_json(
                    SYSTEM_SLIDE_ENRICHER,
                    USER_SLIDE_ENRICHER.format(
                        slide_json=slide.model_dump_json(indent=2),
                        topic=req.topic,
                        tone=req.tone,
                    ),
                    temperature=0.5,
                )
                enriched.append(self._parse_slide(raw))
            except Exception as e:
                logger.warning("Enrichment failed for slide %d: %s", i, e)
                enriched.append(slide)
        plan.slides = enriched
        return plan
