"""
Core data models for the Enterprise PPTX Agent.
"""
from __future__ import annotations
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class ContentType(str, Enum):
    TITLE_SLIDE = "title_slide"
    SECTION_HEADER = "section_header"
    CONTENT = "content"
    TWO_COLUMN = "two_column"
    BULLETS = "bullets"
    IMAGE_CONTENT = "image_content"
    BLANK = "blank"
    TABLE = "table"
    CHART = "chart"
    CLOSING = "closing"


class GenerationStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    FAILED = "failed"


# ---------------------------------------------------------------------------
# Slide-level models
# ---------------------------------------------------------------------------

class BulletPoint(BaseModel):
    text: str
    level: int = 0
    bold: bool = False


class TableData(BaseModel):
    headers: list[str]
    rows: list[list[str]]
    has_header_row: bool = True


class ChartData(BaseModel):
    chart_type: str = "bar"       # bar | line | pie | column
    title: str = ""
    categories: list[str] = Field(default_factory=list)
    series: list[dict[str, Any]] = Field(default_factory=list)  # [{name, values}]


class SlideContent(BaseModel):
    slide_type: ContentType
    title: str = ""
    subtitle: str = ""
    body: str = ""
    bullets: list[BulletPoint] = Field(default_factory=list)
    left_column: str = ""
    right_column: str = ""
    speaker_notes: str = ""
    table: Optional[TableData] = None
    chart: Optional[ChartData] = None
    image_prompt: str = ""          # future: AI image generation
    layout_index: Optional[int] = None   # override auto-selected layout


# ---------------------------------------------------------------------------
# Presentation-level models
# ---------------------------------------------------------------------------

class PresentationRequest(BaseModel):
    topic: str
    audience: str = "General"
    num_slides: int = Field(default=10, ge=3, le=50)
    tone: str = "professional"      # professional | executive | technical | casual
    template_path: Optional[str] = None
    extra_instructions: str = ""
    include_speaker_notes: bool = True
    language: str = "en"


class PresentationPlan(BaseModel):
    title: str
    subtitle: str = ""
    slides: list[SlideContent] = Field(default_factory=list)
    theme_color: str = ""


class GenerationJob(BaseModel):
    job_id: str
    request: PresentationRequest
    status: GenerationStatus = GenerationStatus.PENDING
    plan: Optional[PresentationPlan] = None
    output_path: Optional[str] = None
    error: Optional[str] = None
    progress: int = 0               # 0-100
    log: list[str] = Field(default_factory=list)
