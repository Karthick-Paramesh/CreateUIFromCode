"""
LLM abstraction layer.

Supports:
- OpenAI / Azure OpenAI
- Any OpenAI-compatible endpoint (Ollama, LM Studio, vLLM, etc.)
- Disabled / stub mode (returns canned content so the app still runs)
"""
from __future__ import annotations
import json
import logging
import os
from abc import ABC, abstractmethod
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class LLMClient(ABC):
    """Abstract base – all providers implement this."""

    @abstractmethod
    def complete(self, system: str, user: str, temperature: float = 0.7,
                 max_tokens: int = 4096) -> str:
        """Return a text completion."""

    def complete_json(self, system: str, user: str, **kwargs) -> Any:
        """Convenience: complete and parse JSON from the response."""
        raw = self.complete(system, user + "\n\nRespond with valid JSON only.", **kwargs)
        # Strip markdown fences if present
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
            raw = raw.rsplit("```", 1)[0]
        return json.loads(raw)


# ---------------------------------------------------------------------------
# Stub (no LLM)
# ---------------------------------------------------------------------------

class StubLLMClient(LLMClient):
    """Returns hard-coded structure. Lets the whole pipeline run with no AI."""

    def complete(self, system: str, user: str, **kwargs) -> str:
        return json.dumps({
            "title": "Sample Presentation",
            "subtitle": "Generated without AI",
            "slides": [
                {
                    "slide_type": "title_slide",
                    "title": "Sample Presentation",
                    "subtitle": "AI disabled – stub content",
                    "speaker_notes": "Replace with real content."
                },
                {
                    "slide_type": "bullets",
                    "title": "Key Points",
                    "bullets": [
                        {"text": "Point one", "level": 0},
                        {"text": "Supporting detail", "level": 1},
                        {"text": "Point two", "level": 0}
                    ],
                    "speaker_notes": "Expand on each point."
                },
                {
                    "slide_type": "closing",
                    "title": "Thank You",
                    "subtitle": "Questions?",
                    "speaker_notes": "Open the floor."
                }
            ]
        })


# ---------------------------------------------------------------------------
# OpenAI / Azure OpenAI / compatible endpoint
# ---------------------------------------------------------------------------

class OpenAICompatibleClient(LLMClient):
    """
    Works with:
      - OpenAI (base_url = None)
      - Azure OpenAI  (base_url = https://<resource>.openai.azure.com, api_version required)
      - Ollama        (base_url = http://localhost:11434/v1, api_key = "ollama")
      - LM Studio     (base_url = http://localhost:1234/v1,  api_key = "lm-studio")
      - vLLM          (base_url = http://localhost:8000/v1,  api_key = "EMPTY")
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o",
        base_url: Optional[str] = None,
        api_version: Optional[str] = None,      # Azure only
        timeout: int = 120,
    ):
        try:
            import openai
        except ImportError:
            raise RuntimeError("openai package not installed. Run: pip install openai")

        self.model = model

        if api_version:
            # Azure
            self._client = openai.AzureOpenAI(
                api_key=api_key,
                azure_endpoint=base_url,
                api_version=api_version,
                timeout=timeout,
            )
        else:
            self._client = openai.OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=timeout,
            )

    def complete(self, system: str, user: str, temperature: float = 0.7,
                 max_tokens: int = 4096) -> str:
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_llm_client(config: dict) -> LLMClient:
    """
    Build an LLM client from a config dict.

    Config keys:
        provider   : "openai" | "azure" | "compatible" | "disabled"
        api_key    : str
        model      : str
        base_url   : str  (for azure / compatible)
        api_version: str  (azure only)
    """
    provider = config.get("provider", "disabled").lower()

    if provider == "disabled":
        logger.info("LLM disabled – using stub client")
        return StubLLMClient()

    if provider in ("openai", "azure", "compatible"):
        return OpenAICompatibleClient(
            api_key=config.get("api_key", os.getenv("OPENAI_API_KEY", "")),
            model=config.get("model", "gpt-4o"),
            base_url=config.get("base_url"),
            api_version=config.get("api_version"),
        )

    raise ValueError(f"Unknown LLM provider: {provider!r}")
