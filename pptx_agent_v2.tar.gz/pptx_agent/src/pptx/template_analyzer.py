"""
Template Analyzer

Inspects a .pptx file and extracts metadata about available slide layouts
so the layout selector can make informed choices.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class PlaceholderInfo:
    idx: int
    ph_type: str        # body, title, subtitle, etc.
    name: str
    width: float        # EMU
    height: float       # EMU
    left: float
    top: float


@dataclass
class LayoutInfo:
    index: int
    name: str
    placeholders: list[PlaceholderInfo] = field(default_factory=list)

    @property
    def placeholder_types(self) -> list[str]:
        return [p.ph_type for p in self.placeholders]

    @property
    def has_title(self) -> bool:
        return any(p.ph_type in ("title", "ctrTitle") for p in self.placeholders)

    @property
    def has_body(self) -> bool:
        return any(p.ph_type == "body" for p in self.placeholders)

    @property
    def has_subtitle(self) -> bool:
        return any(p.ph_type in ("subTitle", "subtitle") for p in self.placeholders)

    @property
    def body_count(self) -> int:
        return sum(1 for p in self.placeholders if p.ph_type == "body")


@dataclass
class TemplateInfo:
    path: str
    slide_width: float      # EMU
    slide_height: float     # EMU
    layouts: list[LayoutInfo] = field(default_factory=list)
    theme_colors: dict[str, str] = field(default_factory=dict)   # name → hex

    @property
    def layout_names(self) -> list[str]:
        return [l.name for l in self.layouts]


class TemplateAnalyzer:
    """
    Extracts structural metadata from a PowerPoint template.
    Results are used downstream by LayoutSelector and SlidePopulator.
    """

    def analyze(self, pptx_path: str) -> TemplateInfo:
        from pptx import Presentation
        from pptx.util import Emu
        from pptx.dml.color import RGBColor
        from lxml import etree

        prs = Presentation(pptx_path)
        info = TemplateInfo(
            path=pptx_path,
            slide_width=prs.slide_width,
            slide_height=prs.slide_height,
        )

        # Extract theme colors
        try:
            info.theme_colors = self._extract_theme_colors(prs)
        except Exception as e:
            logger.warning("Could not extract theme colors: %s", e)

        # Extract layouts from all slide masters
        layout_index = 0
        for master in prs.slide_masters:
            for layout in master.slide_layouts:
                li = LayoutInfo(index=layout_index, name=layout.name)
                for ph in layout.placeholders:
                    sp = ph.element
                    nvSpPr = sp.find(".//{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}nvPr")
                    ph_type = ph.placeholder_format.type.name if ph.placeholder_format else "body"
                    pi = PlaceholderInfo(
                        idx=ph.placeholder_format.idx if ph.placeholder_format else 0,
                        ph_type=ph_type,
                        name=ph.name,
                        width=ph.width or 0,
                        height=ph.height or 0,
                        left=ph.left or 0,
                        top=ph.top or 0,
                    )
                    li.placeholders.append(pi)
                info.layouts.append(li)
                layout_index += 1

        logger.info("Analyzed template: %d layouts found", len(info.layouts))
        return info

    def analyze_from_presentation(self, prs) -> "TemplateInfo":
        """Analyze an already-loaded Presentation object (no file path needed)."""
        info = TemplateInfo(
            path="<in-memory>",
            slide_width=prs.slide_width,
            slide_height=prs.slide_height,
        )
        layout_index = 0
        for master in prs.slide_masters:
            for layout in master.slide_layouts:
                li = LayoutInfo(index=layout_index, name=layout.name)
                for ph in layout.placeholders:
                    ph_type = ph.placeholder_format.type.name if ph.placeholder_format else "body"
                    pi = PlaceholderInfo(
                        idx=ph.placeholder_format.idx if ph.placeholder_format else 0,
                        ph_type=ph_type,
                        name=ph.name,
                        width=ph.width or 0,
                        height=ph.height or 0,
                        left=ph.left or 0,
                        top=ph.top or 0,
                    )
                    li.placeholders.append(pi)
                info.layouts.append(li)
                layout_index += 1
        logger.info("Analyzed in-memory presentation: %d layouts found", len(info.layouts))
        return info

    def _extract_theme_colors(self, prs) -> dict[str, str]:
        """Best-effort extraction of the theme's color scheme."""
        from lxml import etree
        colors: dict[str, str] = {}
        ns = "http://schemas.openxmlformats.org/drawingml/2006/main"
        for master in prs.slide_masters:
            theme_elem = master.element.find(f".//{{{ns}}}theme")
            if theme_elem is None:
                # Try the theme relationship
                for rel in master.part.rels.values():
                    if "theme" in rel.reltype:
                        try:
                            root = etree.fromstring(rel.target_part.blob)
                            theme_elem = root
                        except Exception:
                            pass
            if theme_elem is not None:
                for color_node in theme_elem.iter(f"{{{ns}}}srgbClr"):
                    name = color_node.get("val", "")
                    if name:
                        parent_tag = color_node.getparent().tag.split("}")[-1]
                        colors[parent_tag] = name
                break
        return colors
