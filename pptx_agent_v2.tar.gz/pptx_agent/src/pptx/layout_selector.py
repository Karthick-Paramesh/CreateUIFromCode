"""
Layout Selector

Given a SlideContent and a TemplateInfo, picks the best matching layout.
Falls back to a reasonable default when no perfect match exists.
"""
from __future__ import annotations
import logging
import re
from typing import Optional

from ..models import ContentType, SlideContent
from .template_analyzer import LayoutInfo, TemplateInfo

logger = logging.getLogger(__name__)


# Heuristic keyword sets that usually appear in layout names
_LAYOUT_KEYWORDS: dict[ContentType, list[str]] = {
    ContentType.TITLE_SLIDE:    ["title slide", "cover", "title page", "opening"],
    ContentType.SECTION_HEADER: ["section", "divider", "chapter", "transition"],
    ContentType.BULLETS:        ["bullet", "content", "text", "body"],
    ContentType.TWO_COLUMN:     ["two column", "2 column", "comparison", "side by side"],
    ContentType.CONTENT:        ["content", "blank content", "body"],
    ContentType.TABLE:          ["table"],
    ContentType.CHART:          ["chart", "graph", "diagram"],
    ContentType.IMAGE_CONTENT:  ["picture", "image", "photo", "media"],
    ContentType.CLOSING:        ["end", "closing", "thank", "final", "last"],
    ContentType.BLANK:          ["blank"],
}


class LayoutSelector:
    """
    Selects the most appropriate slide layout from a template.

    Strategy:
      1. If slide.layout_index is set, use it directly.
      2. Keyword-match layout names.
      3. Structural fallback (check placeholder composition).
      4. Ultimate fallback: layout index 1 (almost always a content layout).
    """

    def __init__(self, template_info: TemplateInfo):
        self._info = template_info
        self._cache: dict[ContentType, int] = {}   # memoize

    def select(self, slide: SlideContent) -> int:
        """Return the layout index to use for this slide."""
        if slide.layout_index is not None:
            return slide.layout_index

        if slide.slide_type in self._cache:
            return self._cache[slide.slide_type]

        idx = (
            self._keyword_match(slide.slide_type)
            or self._structural_match(slide.slide_type)
            or self._safe_default(slide.slide_type)
        )
        self._cache[slide.slide_type] = idx
        logger.debug("Layout for %s → %d (%s)",
                     slide.slide_type, idx, self._info.layouts[idx].name)
        return idx

    # ------------------------------------------------------------------
    def _keyword_match(self, ct: ContentType) -> Optional[int]:
        keywords = _LAYOUT_KEYWORDS.get(ct, [])
        for kw in keywords:
            for layout in self._info.layouts:
                if kw in layout.name.lower():
                    return layout.index
        return None

    def _structural_match(self, ct: ContentType) -> Optional[int]:
        """Use placeholder structure as a fallback signal."""
        for layout in self._info.layouts:
            if ct == ContentType.TITLE_SLIDE and layout.has_title and layout.has_subtitle and not layout.has_body:
                return layout.index
            if ct == ContentType.SECTION_HEADER and layout.has_title and not layout.has_body:
                return layout.index
            if ct in (ContentType.BULLETS, ContentType.CONTENT) and layout.has_title and layout.has_body:
                return layout.index
            if ct == ContentType.TWO_COLUMN and layout.body_count >= 2:
                return layout.index
            if ct == ContentType.BLANK and not layout.has_title and not layout.has_body:
                return layout.index
        return None

    def _safe_default(self, ct: ContentType) -> int:
        """Absolute fallback."""
        layouts = self._info.layouts
        if not layouts:
            return 0
        # Title slide → prefer 0, everything else → 1 (or last available)
        if ct == ContentType.TITLE_SLIDE:
            return 0
        return min(1, len(layouts) - 1)
