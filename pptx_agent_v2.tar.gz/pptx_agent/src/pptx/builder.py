"""
Presentation Builder

Ties together TemplateAnalyzer, LayoutSelector, and SlidePopulator
to produce a complete .pptx file from a PresentationPlan.
"""
from __future__ import annotations
import logging
import uuid
from pathlib import Path
from typing import Callable, Optional

from pptx import Presentation
from pptx.util import Inches, Pt

from ..models import PresentationPlan, SlideContent
from .template_analyzer import TemplateAnalyzer, TemplateInfo
from .layout_selector import LayoutSelector
from .slide_populator import SlidePopulator

logger = logging.getLogger(__name__)

DEFAULT_TEMPLATE_PATH = Path(__file__).parent.parent.parent / "templates" / "default.pptx"


class PresentationBuilder:
    """
    Builds a .pptx from a PresentationPlan.

    Usage:
        builder = PresentationBuilder()
        path = builder.build(plan, output_dir="./output")
    """

    def __init__(self, template_path: Optional[str] = None):
        self._template_path = template_path
        self._analyzer = TemplateAnalyzer()
        self._populator = SlidePopulator()
        self._template_info: Optional[TemplateInfo] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build(
        self,
        plan: PresentationPlan,
        output_dir: str = ".",
        filename: Optional[str] = None,
        progress_cb: Optional[Callable[[int, str], None]] = None,
    ) -> str:
        """
        Build the presentation and return the output file path.

        Args:
            plan:        Structured presentation content.
            output_dir:  Directory where the .pptx will be written.
            filename:    Override output filename (auto-generated if None).
            progress_cb: Optional callback(percent, message) for progress UI.
        """
        def _progress(pct: int, msg: str):
            if progress_cb:
                progress_cb(pct, msg)
            logger.debug("[%d%%] %s", pct, msg)

        _progress(5, "Loading template…")
        prs, template_info = self._load_template()
        selector = LayoutSelector(template_info)

        total = len(plan.slides)
        for i, slide_content in enumerate(plan.slides):
            pct = 10 + int(80 * i / total)
            _progress(pct, f"Building slide {i+1}/{total}: {slide_content.title!r}")

            layout_idx = selector.select(slide_content)
            layout = self._get_layout(prs, layout_idx)
            slide = prs.slides.add_slide(layout)
            self._populator.populate(slide, slide_content)

        _progress(92, "Saving file…")
        output_path = self._save(prs, output_dir, filename or self._auto_filename(plan))
        _progress(100, "Done")
        return output_path

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _load_template(self):
        """Load the Presentation object from the template file."""
        template_path = self._template_path or str(DEFAULT_TEMPLATE_PATH)

        if Path(template_path).exists():
            prs = Presentation(template_path)
            info = self._analyzer.analyze(template_path)
        else:
            logger.warning("Template not found at %s – creating blank presentation", template_path)
            prs = Presentation()
            info = self._analyzer.analyze_from_presentation(prs)

        self._template_info = info
        return prs, info

    def _get_layout(self, prs: Presentation, layout_idx: int):
        """Get a layout across all masters by flat index."""
        flat_idx = 0
        for master in prs.slide_masters:
            for layout in master.slide_layouts:
                if flat_idx == layout_idx:
                    return layout
                flat_idx += 1
        # Fallback: first available layout
        return prs.slide_masters[0].slide_layouts[0]

    def _save(self, prs: Presentation, output_dir: str, filename: str) -> str:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        path = out / filename
        prs.save(str(path))
        logger.info("Saved presentation: %s", path)
        return str(path)

    def _auto_filename(self, plan: PresentationPlan) -> str:
        safe_title = "".join(c if c.isalnum() or c in " _-" else "" for c in plan.title)
        safe_title = safe_title.strip().replace(" ", "_")[:40]
        uid = uuid.uuid4().hex[:6]
        return f"{safe_title}_{uid}.pptx"
