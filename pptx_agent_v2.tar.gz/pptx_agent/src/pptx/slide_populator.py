"""
Slide Populator

Takes a python-pptx slide (already created from the correct layout)
and fills it with content from a SlideContent model.
"""
from __future__ import annotations
import logging
from typing import Optional

from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.chart import XL_CHART_TYPE

from ..models import ContentType, SlideContent, BulletPoint, TableData, ChartData

logger = logging.getLogger(__name__)

# Placeholder type constants
_PH_TITLE    = {1, 13}   # PP_PLACEHOLDER.TITLE, CENTER_TITLE
_PH_SUBTITLE = {12}       # PP_PLACEHOLDER.SUBTITLE
_PH_BODY     = {2, 7, 15} # BODY, OBJECT, PICTURE


class SlidePopulator:
    """
    Writes structured SlideContent into an existing python-pptx slide object.
    Handles all ContentType variants.
    """

    def populate(self, slide, content: SlideContent) -> None:
        """Entry point – dispatch by content type."""
        ct = content.slide_type
        try:
            if ct == ContentType.TITLE_SLIDE:
                self._do_title_slide(slide, content)
            elif ct == ContentType.SECTION_HEADER:
                self._do_section_header(slide, content)
            elif ct == ContentType.CLOSING:
                self._do_closing(slide, content)
            elif ct == ContentType.BULLETS:
                self._do_bullets(slide, content)
            elif ct == ContentType.TWO_COLUMN:
                self._do_two_column(slide, content)
            elif ct == ContentType.TABLE:
                self._do_table(slide, content)
            elif ct == ContentType.CHART:
                self._do_chart(slide, content)
            elif ct in (ContentType.CONTENT, ContentType.IMAGE_CONTENT):
                self._do_content(slide, content)
            else:
                self._do_content(slide, content)   # BLANK, fallback

            if content.speaker_notes:
                self._set_notes(slide, content.speaker_notes)

        except Exception as exc:
            logger.error("Error populating slide '%s': %s", content.title, exc, exc_info=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_placeholder(self, slide, *ph_types):
        """Return first placeholder matching one of the given types."""
        from pptx.enum.text import PP_ALIGN
        from pptx.util import Pt
        for ph in slide.placeholders:
            if ph.placeholder_format.idx in ph_types or \
               ph.placeholder_format.type.real in ph_types:
                return ph
        return None

    def _set_text_safe(self, placeholder, text: str, bold: bool = False,
                        font_size: Optional[int] = None) -> None:
        if placeholder is None or not text:
            return
        try:
            tf = placeholder.text_frame
            tf.clear()
            p = tf.paragraphs[0]
            run = p.add_run()
            run.text = text
            if bold:
                run.font.bold = True
            if font_size:
                run.font.size = Pt(font_size)
        except Exception as e:
            logger.warning("Could not set text: %s", e)

    def _title_ph(self, slide):
        """Find the title placeholder by index (idx=0 is always title)."""
        for ph in slide.placeholders:
            if ph.placeholder_format.idx == 0:
                return ph
        return None

    def _subtitle_ph(self, slide):
        for ph in slide.placeholders:
            if ph.placeholder_format.idx == 1:
                return ph
        return None

    def _body_phs(self, slide) -> list:
        result = []
        for ph in slide.placeholders:
            if ph.placeholder_format.idx >= 1:
                result.append(ph)
        return result

    # ------------------------------------------------------------------
    # Title slide
    # ------------------------------------------------------------------

    def _do_title_slide(self, slide, c: SlideContent) -> None:
        title_ph = self._title_ph(slide)
        subtitle_ph = self._subtitle_ph(slide)
        self._set_text_safe(title_ph, c.title)
        self._set_text_safe(subtitle_ph, c.subtitle or c.body)

    # ------------------------------------------------------------------
    # Section header
    # ------------------------------------------------------------------

    def _do_section_header(self, slide, c: SlideContent) -> None:
        title_ph = self._title_ph(slide)
        subtitle_ph = self._subtitle_ph(slide)
        self._set_text_safe(title_ph, c.title)
        if c.subtitle:
            self._set_text_safe(subtitle_ph, c.subtitle)

    # ------------------------------------------------------------------
    # Closing
    # ------------------------------------------------------------------

    def _do_closing(self, slide, c: SlideContent) -> None:
        self._do_title_slide(slide, c)

    # ------------------------------------------------------------------
    # Bullets
    # ------------------------------------------------------------------

    def _do_bullets(self, slide, c: SlideContent) -> None:
        title_ph = self._title_ph(slide)
        self._set_text_safe(title_ph, c.title)

        # Find the body placeholder (idx > 0 and not the subtitle)
        body_ph = None
        for ph in slide.placeholders:
            if ph.placeholder_format.idx >= 2:
                body_ph = ph
                break
        if body_ph is None and len(list(slide.placeholders)) > 1:
            phs = list(slide.placeholders)
            body_ph = phs[1]

        if body_ph is None:
            logger.warning("No body placeholder for bullets slide: %s", c.title)
            return

        tf = body_ph.text_frame
        tf.clear()
        tf.word_wrap = True

        bullets = c.bullets or [BulletPoint(text=c.body)]
        for i, bp in enumerate(bullets):
            if i == 0:
                para = tf.paragraphs[0]
            else:
                para = tf.add_paragraph()
            para.level = bp.level
            run = para.add_run()
            run.text = bp.text
            if bp.bold:
                run.font.bold = True

    # ------------------------------------------------------------------
    # Two-column
    # ------------------------------------------------------------------

    def _do_two_column(self, slide, c: SlideContent) -> None:
        title_ph = self._title_ph(slide)
        self._set_text_safe(title_ph, c.title)

        body_phs = [ph for ph in slide.placeholders if ph.placeholder_format.idx >= 2]
        if len(body_phs) >= 2:
            self._set_text_safe(body_phs[0], c.left_column)
            self._set_text_safe(body_phs[1], c.right_column)
        elif len(body_phs) == 1:
            combined = f"{c.left_column}\n\n{c.right_column}"
            self._set_text_safe(body_phs[0], combined)
        else:
            # Fall back to adding text boxes manually
            self._add_text_box(slide, c.left_column,
                               Inches(0.5), Inches(2), Inches(4.2), Inches(4))
            self._add_text_box(slide, c.right_column,
                               Inches(5), Inches(2), Inches(4.2), Inches(4))

    def _add_text_box(self, slide, text: str,
                       left, top, width, height) -> None:
        if not text:
            return
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        tf.word_wrap = True
        tf.text = text

    # ------------------------------------------------------------------
    # Content (generic body text)
    # ------------------------------------------------------------------

    def _do_content(self, slide, c: SlideContent) -> None:
        title_ph = self._title_ph(slide)
        self._set_text_safe(title_ph, c.title)

        body_text = c.body or c.subtitle
        for ph in slide.placeholders:
            if ph.placeholder_format.idx >= 2:
                self._set_text_safe(ph, body_text)
                return
        # No body placeholder: add a text box
        if body_text:
            self._add_text_box(slide, body_text,
                               Inches(0.5), Inches(2), Inches(9), Inches(4.5))

    # ------------------------------------------------------------------
    # Table
    # ------------------------------------------------------------------

    def _do_table(self, slide, c: SlideContent) -> None:
        from pptx.util import Inches, Pt
        title_ph = self._title_ph(slide)
        self._set_text_safe(title_ph, c.title)

        if not c.table:
            return

        td: TableData = c.table
        rows = len(td.rows) + (1 if td.has_header_row else 0)
        cols = max(len(td.headers), max((len(r) for r in td.rows), default=0))
        if rows == 0 or cols == 0:
            return

        left, top = Inches(0.5), Inches(1.8)
        width, height = Inches(9), Inches(4.5)
        table = slide.shapes.add_table(rows, cols, left, top, width, height).table

        start_row = 0
        if td.has_header_row and td.headers:
            for ci, hdr in enumerate(td.headers):
                if ci < cols:
                    cell = table.cell(0, ci)
                    cell.text = hdr
                    cell.text_frame.paragraphs[0].runs[0].font.bold = True
            start_row = 1

        for ri, row in enumerate(td.rows):
            for ci, val in enumerate(row):
                if ci < cols:
                    table.cell(start_row + ri, ci).text = val

    # ------------------------------------------------------------------
    # Chart
    # ------------------------------------------------------------------

    def _do_chart(self, slide, c: SlideContent) -> None:
        from pptx.chart.data import ChartData as PptxChartData
        from pptx.util import Inches
        from pptx.enum.chart import XL_CHART_TYPE

        title_ph = self._title_ph(slide)
        self._set_text_safe(title_ph, c.title)

        if not c.chart:
            return

        cd: ChartData = c.chart
        chart_type_map = {
            "bar":    XL_CHART_TYPE.BAR_CLUSTERED,
            "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
            "line":   XL_CHART_TYPE.LINE,
            "pie":    XL_CHART_TYPE.PIE,
        }
        chart_type = chart_type_map.get(cd.chart_type.lower(), XL_CHART_TYPE.BAR_CLUSTERED)

        chart_data = PptxChartData()
        chart_data.categories = cd.categories
        for s in cd.series:
            chart_data.add_series(s.get("name", ""), s.get("values", []))

        left, top = Inches(0.5), Inches(1.8)
        width, height = Inches(9), Inches(4.5)
        chart = slide.shapes.add_chart(chart_type, left, top, width, height, chart_data).chart
        if cd.title:
            chart.has_title = True
            chart.chart_title.text_frame.text = cd.title

    # ------------------------------------------------------------------
    # Speaker notes
    # ------------------------------------------------------------------

    def _set_notes(self, slide, notes_text: str) -> None:
        try:
            notes_slide = slide.notes_slide
            tf = notes_slide.notes_text_frame
            tf.text = notes_text
        except Exception as e:
            logger.debug("Could not set speaker notes: %s", e)
