# Enterprise PPTX Agent

A local-first, AI-augmented Python agent that generates professional PowerPoint
presentations from a plain-text brief.

Works fully **offline / in stub mode** — no AI key required to run.

---

## Quick Start

```bash
# 1. Install Python dependencies
pip install -r requirements.txt
pip install fastapi uvicorn python-multipart

# 2. Configure (optional — defaults to stub/no-AI mode)
cp .env.example .env
# edit .env to set LLM_PROVIDER and credentials

# 3. Start the FastAPI backend
uvicorn api:app --reload --port 8000

# 4. Start the React frontend (new terminal)
cd frontend
npm install
npm run dev
# → open http://localhost:5173

# 5. Or use the CLI (no frontend needed)
python cli.py --topic "Q3 Business Review" --slides 10 --audience "Board"
```

---

## Project Structure

```
pptx_agent/
├── api.py              FastAPI backend (SSE streaming)
├── cli.py              Command-line interface
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx    React entry point
│       └── App.jsx     Full React UI (single-file)
├── requirements.txt
├── .env.example        Environment variable template
├── config/settings.py  Typed config (reads .env)
├── src/
│   ├── models.py           Pydantic data models
│   ├── agent/orchestrator.py   Pipeline controller
│   ├── llm/base.py             LLM abstraction + providers
│   ├── llm/prompts.py          Prompt templates
│   └── pptx/
│       ├── template_analyzer.py
│       ├── layout_selector.py
│       ├── slide_populator.py
│       └── builder.py
├── templates/          Put your .pptx template here
├── tests/test_agent.py 25 pytest tests
└── docs/ARCHITECTURE.md Full architecture document
```

---

## LLM Providers

| Provider | `LLM_PROVIDER` | Notes |
|---|---|---|
| None (stub) | `disabled` | Fully local, no API calls, canned content |
| OpenAI | `openai` | Set `LLM_API_KEY` |
| Azure OpenAI | `azure` | Set `LLM_BASE_URL` + `LLM_API_VERSION` |
| Ollama (local) | `compatible` | `LLM_BASE_URL=http://localhost:11434/v1` |
| LM Studio | `compatible` | `LLM_BASE_URL=http://localhost:1234/v1` |
| vLLM | `compatible` | Set your vLLM endpoint as `LLM_BASE_URL` |

---

## Running Tests

```bash
python -m pytest tests/ -v
```

---

## Corporate Template

Upload your `.pptx` template in the Streamlit sidebar, or pass `--template path/to/corp.pptx`
in the CLI. The agent auto-discovers all slide layouts and selects the best match per slide type.

See `docs/ARCHITECTURE.md` for the full design, roadmap, and risk register.
