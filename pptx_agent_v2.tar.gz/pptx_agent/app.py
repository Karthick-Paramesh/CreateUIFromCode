"""
Enterprise PPTX Agent — Streamlit UI
"""
import logging
import sys
from pathlib import Path

import streamlit as st

# Make sure src/ is importable
sys.path.insert(0, str(Path(__file__).parent))

from config.settings import load_config, AppConfig, LLMConfig
from src.llm.base import build_llm_client
from src.models import PresentationRequest, GenerationStatus
from src.agent.orchestrator import PresentationOrchestrator
from src.pptx.builder import PresentationBuilder

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)-8s %(name)s — %(message)s")

# ──────────────────────────────────────────────────────────────────────────────
# Page config
# ──────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Enterprise PPTX Agent",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────────────────────────────────────
# CSS
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .stApp { background: #F7F8FA; }
    section[data-testid="stSidebar"] { background: #1E2533; }
    section[data-testid="stSidebar"] * { color: #DDE3F0 !important; }
    section[data-testid="stSidebar"] input,
    section[data-testid="stSidebar"] select,
    section[data-testid="stSidebar"] textarea {
        background: #2A3248 !important;
        border: 1px solid #3D4F6E !important;
        color: #EEF1F8 !important;
        border-radius: 6px !important;
    }
    .hero-header {
        background: linear-gradient(135deg, #1E2761 0%, #2D5A8E 60%, #0A9396 100%);
        color: white;
        padding: 2.5rem 2rem;
        border-radius: 12px;
        margin-bottom: 2rem;
    }
    .hero-header h1 { font-size: 2rem; font-weight: 700; margin: 0 0 0.4rem; }
    .hero-header p  { opacity: 0.82; margin: 0; font-size: 1rem; }
    .status-badge {
        display: inline-block;
        padding: 3px 12px;
        border-radius: 20px;
        font-size: 0.82rem;
        font-weight: 600;
        letter-spacing: 0.03em;
    }
    .badge-ok      { background:#d4edda; color:#155724; }
    .badge-warn    { background:#fff3cd; color:#856404; }
    .badge-error   { background:#f8d7da; color:#721c24; }
    .log-box {
        background:#0d1117; color:#c9d1d9;
        font-family: monospace; font-size: 0.78rem;
        padding: 1rem; border-radius: 8px;
        max-height: 280px; overflow-y: auto;
    }
    div[data-testid="stButton"] button {
        border-radius: 8px;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────────
# Sidebar — LLM & template settings
# ──────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")

    st.markdown("### LLM Provider")
    provider = st.selectbox(
        "Provider",
        ["disabled", "openai", "azure", "compatible"],
        help="'disabled' uses stub content so the pipeline still runs without AI.",
    )

    api_key = ""
    base_url = ""
    api_version = ""
    model = "gpt-4o"

    if provider != "disabled":
        api_key  = st.text_input("API Key", type="password", placeholder="sk-…")
        model    = st.text_input("Model", value="gpt-4o")
        if provider in ("azure", "compatible"):
            base_url    = st.text_input("Endpoint URL", placeholder="https://…")
        if provider == "azure":
            api_version = st.text_input("API Version", value="2024-02-01")

    st.markdown("---")
    st.markdown("### Template")
    template_file = st.file_uploader(
        "Upload corporate .pptx template (optional)",
        type=["pptx"],
        help="Upload your company's master template. If omitted, a blank presentation is used.",
    )

    st.markdown("---")
    st.markdown("### Advanced")
    enrich_slides = st.toggle(
        "Per-slide enrichment",
        value=False,
        help="Run a second LLM pass per slide for richer copy. Slower and uses more tokens.",
    )
    output_dir = st.text_input("Output directory", value="./output")

    # Connection status badge
    status_html = (
        '<span class="status-badge badge-ok">✓ AI enabled</span>'
        if provider != "disabled"
        else '<span class="status-badge badge-warn">⚠ AI disabled (stub mode)</span>'
    )
    st.markdown(status_html, unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────────
# Hero
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero-header">
  <h1>📊 Enterprise PPTX Agent</h1>
  <p>Generate professional PowerPoint presentations from a topic — powered by AI or in stub mode.</p>
</div>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────────
# Main form
# ──────────────────────────────────────────────────────────────────────────────
col1, col2 = st.columns([3, 2], gap="large")

with col1:
    st.subheader("Presentation Brief")
    topic = st.text_area(
        "Topic / brief",
        placeholder="e.g. Q3 2025 Business Review – Sales performance, market headwinds, and Q4 outlook",
        height=120,
    )
    extra = st.text_area(
        "Extra instructions (optional)",
        placeholder="e.g. Include a risk matrix slide. Focus on APAC market. Avoid acronyms.",
        height=80,
    )

with col2:
    st.subheader("Options")
    audience = st.text_input("Target audience", value="Executive leadership team")
    num_slides = st.slider("Number of slides", min_value=3, max_value=30, value=10)
    tone = st.selectbox("Tone", ["professional", "executive", "technical", "casual"])
    language = st.selectbox("Language", ["en", "de", "fr", "es", "it", "pt", "nl"])

st.markdown("---")
generate_btn = st.button("🚀 Generate Presentation", type="primary", use_container_width=True)


# ──────────────────────────────────────────────────────────────────────────────
# Generation
# ──────────────────────────────────────────────────────────────────────────────
if generate_btn:
    if not topic.strip():
        st.error("Please enter a topic before generating.")
        st.stop()

    # Save uploaded template to disk if provided
    template_path = None
    if template_file:
        tmp = Path("/tmp") / template_file.name
        tmp.write_bytes(template_file.getvalue())
        template_path = str(tmp)

    # Build clients
    llm_cfg = LLMConfig(
        provider=provider,
        api_key=api_key,
        model=model,
        base_url=base_url,
        api_version=api_version,
    )
    llm_client = build_llm_client(llm_cfg.__dict__)
    builder    = PresentationBuilder(template_path=template_path)
    agent      = PresentationOrchestrator(llm_client, builder, enrich_slides=enrich_slides)

    request = PresentationRequest(
        topic=topic,
        audience=audience,
        num_slides=num_slides,
        tone=tone,
        language=language,
        extra_instructions=extra,
        template_path=template_path,
    )

    # Progress UI
    progress_bar  = st.progress(0)
    status_text   = st.empty()
    log_container = st.empty()
    log_lines: list[str] = []

    def on_progress(pct: int, msg: str):
        progress_bar.progress(pct / 100)
        status_text.markdown(f"**{msg}**")
        log_lines.append(f"[{pct:3d}%] {msg}")
        log_container.markdown(
            '<div class="log-box">' + "<br>".join(log_lines[-20:]) + "</div>",
            unsafe_allow_html=True,
        )

    with st.spinner("Generating…"):
        job = agent.run(request, output_dir=output_dir, progress_cb=on_progress)

    # Result
    if job.status == GenerationStatus.COMPLETE:
        progress_bar.progress(1.0)
        st.success(f"✅ Presentation generated: `{job.output_path}`")

        # Download button
        with open(job.output_path, "rb") as f:
            st.download_button(
                label="⬇️ Download .pptx",
                data=f.read(),
                file_name=Path(job.output_path).name,
                mime="application/vnd.openxmlformats-officedocument.presentationml.presentation",
                use_container_width=True,
            )

        # Slide plan preview
        if job.plan:
            with st.expander("📋 Slide plan", expanded=False):
                for i, slide in enumerate(job.plan.slides, 1):
                    st.markdown(f"**{i}. [{slide.slide_type.value}]** {slide.title}")

    else:
        progress_bar.progress(1.0)
        st.error(f"❌ Generation failed: {job.error}")
        with st.expander("Full log"):
            st.code("\n".join(job.log))

# ──────────────────────────────────────────────────────────────────────────────
# Footer
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown(
    "<small style='color:#999'>Enterprise PPTX Agent · runs locally · no data leaves your machine</small>",
    unsafe_allow_html=True,
)
