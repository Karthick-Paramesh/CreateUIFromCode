# Enterprise PPTX Agent — Architecture Document

## 1. Overview

The Enterprise PPTX Agent is a local-first, AI-augmented Python system that
generates professional PowerPoint presentations from a plain-text brief.

It is designed for corporate environments where:
- Internet access may be restricted
- Microsoft Office may not be installed
- SaaS tools may be prohibited
- A small engineering team (2–5 devs) owns the codebase

---

## 2. High-Level Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                         User Interface                        │
│           Streamlit Web App  │  CLI (cli.py)                 │
└────────────────────┬─────────────────────────────────────────┘
                     │  PresentationRequest
                     ▼
┌──────────────────────────────────────────────────────────────┐
│                    Orchestrator Agent                         │
│  1. Plan (LLM)  →  2. Enrich (optional)  →  3. Build PPTX   │
└────────┬──────────────────────┬────────────────────┬─────────┘
         │                      │                    │
         ▼                      │                    ▼
┌─────────────────┐             │       ┌────────────────────────┐
│   LLM Layer     │             │       │   PPTX Builder         │
│ ─────────────── │             │       │ ───────────────────── │
│ StubLLMClient   │             │       │ TemplateAnalyzer       │
│ OpenAICompat.   │             │       │ LayoutSelector         │
│ (Azure/local/   │             │       │ SlidePopulator         │
│  OpenAI)        │             │       └────────────────────────┘
└─────────────────┘             │                    │
                                │                    ▼
                     PresentationPlan       .pptx file on disk
```

---

## 3. Component Descriptions

### 3.1 LLM Layer (`src/llm/`)

| Class | Purpose |
|---|---|
| `LLMClient` (ABC) | Interface all providers implement |
| `StubLLMClient` | Returns canned JSON; keeps pipeline runnable without AI |
| `OpenAICompatibleClient` | Works with OpenAI, Azure OpenAI, Ollama, LM Studio, vLLM |
| `build_llm_client(config)` | Factory — reads `LLM_PROVIDER` and instantiates the right client |

**Switching providers requires only an env-var change** — no code change.

### 3.2 Orchestrator (`src/agent/orchestrator.py`)

The main controller. Runs in three phases:

1. **Plan** — sends topic/audience/tone to LLM; receives a structured JSON plan
2. **Enrich** (optional) — second LLM pass per slide for richer copy
3. **Build** — hands `PresentationPlan` to `PresentationBuilder`

Emits `(pct, message)` progress callbacks consumed by both Streamlit and CLI.

### 3.3 PPTX Builder (`src/pptx/`)

| Class | Responsibility |
|---|---|
| `TemplateAnalyzer` | Inspects `.pptx` template; extracts layout names, placeholder positions, theme colors |
| `LayoutSelector` | Maps `ContentType` → layout index via keyword → structural → safe-default chain |
| `SlidePopulator` | Writes title/bullets/table/chart/two-column content into a `python-pptx` slide |
| `PresentationBuilder` | Orchestrates the three above; saves output file |

### 3.4 Data Models (`src/models.py`)

All data flowing through the pipeline is typed via Pydantic:

```
PresentationRequest
    └─► (LLM) ─► PresentationPlan
                      └─► [SlideContent, ...]
                               ├─ BulletPoint
                               ├─ TableData
                               └─ ChartData
```

---

## 4. Data Flow — Detailed

```
User Input (topic, slides, tone, audience)
  │
  ▼
PresentationRequest (Pydantic model)
  │
  ├─► SYSTEM_PLANNER + USER_PLANNER prompts
  │      │
  │      ▼
  │   LLMClient.complete_json()
  │      │
  │      ▼
  │   raw JSON dict
  │      │
  │      ▼
  │   Orchestrator._parse_plan()  ──►  PresentationPlan
  │
  ▼
PresentationBuilder.build(plan)
  │
  ├─► TemplateAnalyzer.analyze(template.pptx)  ──►  TemplateInfo
  │
  ├─► For each SlideContent in plan.slides:
  │     ├─► LayoutSelector.select(slide)  ──►  layout_index
  │     ├─► prs.slides.add_slide(layout)
  │     └─► SlidePopulator.populate(slide, content)
  │
  └─► prs.save(output.pptx)  ──►  .pptx file
```

---

## 5. LLM Provider Configuration

Set these environment variables (or copy `.env.example` to `.env`):

| Variable | Values | Notes |
|---|---|---|
| `LLM_PROVIDER` | `disabled` / `openai` / `azure` / `compatible` | `disabled` = stub mode |
| `LLM_API_KEY` | string | Not needed for `disabled` |
| `LLM_MODEL` | e.g. `gpt-4o` | Model name or deployment name (Azure) |
| `LLM_BASE_URL` | URL | Required for `azure` and `compatible` |
| `LLM_API_VERSION` | e.g. `2024-02-01` | Azure only |

**Local model examples:**

```bash
# Ollama (llama3, mistral, etc.)
LLM_PROVIDER=compatible
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_MODEL=llama3

# LM Studio
LLM_PROVIDER=compatible
LLM_BASE_URL=http://localhost:1234/v1
LLM_API_KEY=lm-studio
LLM_MODEL=local-model
```

---

## 6. Template Support

The agent works with **any `.pptx` template** that has slide masters and layouts.

- Upload via the Streamlit sidebar or pass `--template` in the CLI
- `TemplateAnalyzer` auto-discovers all layouts across all masters
- `LayoutSelector` picks the best match per slide type using a keyword → structural → default cascade
- If a layout does not have enough placeholders, `SlidePopulator` falls back to adding text boxes

**Without a template:** a blank python-pptx presentation is used. Functional but unstyled.

---

## 7. Repository Structure

```
pptx_agent/
├── app.py                  # Streamlit UI entry point
├── cli.py                  # CLI entry point
├── requirements.txt
├── .env.example
├── config/
│   ├── __init__.py
│   └── settings.py         # Typed config; reads env vars
├── src/
│   ├── models.py           # All Pydantic data models
│   ├── agent/
│   │   └── orchestrator.py # Top-level pipeline controller
│   ├── llm/
│   │   ├── base.py         # LLMClient ABC + providers + factory
│   │   └── prompts.py      # All prompt templates
│   └── pptx/
│       ├── template_analyzer.py
│       ├── layout_selector.py
│       ├── slide_populator.py
│       └── builder.py
├── templates/
│   └── default.pptx        # (optional) bundled corporate template
├── tests/
│   └── test_agent.py       # 25 pytest tests; all green
└── docs/
    └── ARCHITECTURE.md     # This file
```

---

## 8. Implementation Roadmap

### Phase 1 — MVP (Weeks 1–4) ✅ Must Have

- [x] Core pipeline: LLM → plan → PPTX
- [x] Stub mode (no AI required)
- [x] All 9 slide content types (title, bullets, two-column, table, chart, section, content, image, closing)
- [x] Template upload and layout auto-selection
- [x] Streamlit UI with progress feedback and download button
- [x] CLI for scripted / batch use
- [x] Typed Pydantic models throughout
- [x] 25-test pytest suite

### Phase 2 — Quality (Weeks 5–8) Should Have

- [ ] Per-slide enrichment pass toggle (framework exists; needs UI wiring)
- [ ] Chart generation via matplotlib → image → inserted into slide (richer than native pptx charts)
- [ ] Speaker notes review UI in Streamlit
- [ ] Job history / session persistence in Streamlit
- [ ] Template preview (render first slide as PNG on upload)
- [ ] Retry logic on LLM calls (exponential back-off)
- [ ] Logging to file with rotation

### Phase 3 — Enterprise (Weeks 9–12) Future Enhancements

- [ ] Async generation (streaming progress, non-blocking UI)
- [ ] Multi-template library (load from corporate SharePoint / network drive)
- [ ] Image generation integration (Azure DALL-E, local Stable Diffusion)
- [ ] Export to PDF alongside PPTX
- [ ] Batch mode: generate N presentations from a CSV brief sheet
- [ ] SSO / Active Directory integration for the Streamlit app
- [ ] Audit log (who generated what, when)
- [ ] REST API wrapper (FastAPI) for integration with enterprise tools

---

## 9. Key Risks and Mitigations

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| LLM returns malformed JSON | Medium | Medium | `complete_json()` strips fences; `_parse_slide()` skips bad slides with a warning |
| Template layout names differ from expectations | High | Medium | Keyword → structural → safe-default cascade; always falls back gracefully |
| Text overflow in placeholders | High | Medium | `SlidePopulator` uses `word_wrap=True`; future: font-size auto-shrink |
| LLM hallucinated slide count | Low | Low | Plan parsing counts actual slides returned, ignores requested count |
| Corporate proxy blocks LLM endpoint | Medium | High | Stub mode keeps app functional; `LLM_BASE_URL` handles non-standard endpoints |
| `python-pptx` XML corruption on complex templates | Low | High | Wrap all slide operations in try/except; log and skip rather than crash |

---

## 10. MVP Defaults (Recommended)

| Setting | Default | Reason |
|---|---|---|
| `LLM_PROVIDER` | `disabled` | Works out of the box; swap to `openai`/`azure` when key is available |
| `LLM_MODEL` | `gpt-4o` | Best JSON reliability for structured output |
| `num_slides` | `10` | Balances completeness with generation time |
| `enrich_slides` | `false` | Doubles LLM calls; enable only when output quality matters more than speed |
| Template | blank | Ship without one; let teams upload their own |
