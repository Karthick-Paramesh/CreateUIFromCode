"""
Test suite for the Enterprise PPTX Agent.

Run with:  python -m pytest tests/ -v
"""
import json
import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.llm.base import StubLLMClient, OpenAICompatibleClient, build_llm_client
from src.models import (
    PresentationRequest, PresentationPlan, SlideContent,
    ContentType, BulletPoint, TableData, ChartData, GenerationStatus
)
from src.agent.orchestrator import PresentationOrchestrator
from src.pptx.builder import PresentationBuilder
from src.pptx.template_analyzer import TemplateAnalyzer
from src.pptx.layout_selector import LayoutSelector


# ─────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────

@pytest.fixture
def stub_llm():
    return StubLLMClient()


@pytest.fixture
def blank_prs():
    """Return an in-memory Presentation for testing."""
    from pptx import Presentation
    return Presentation()


@pytest.fixture
def template_info(blank_prs):
    analyzer = TemplateAnalyzer()
    return analyzer.analyze_from_presentation(blank_prs)


@pytest.fixture
def sample_request():
    return PresentationRequest(
        topic="AI in Healthcare",
        audience="Hospital board",
        num_slides=5,
        tone="professional",
    )


@pytest.fixture
def sample_plan():
    return PresentationPlan(
        title="AI in Healthcare",
        subtitle="Opportunities and Risks",
        slides=[
            SlideContent(slide_type=ContentType.TITLE_SLIDE,
                         title="AI in Healthcare",
                         subtitle="Opportunities and Risks"),
            SlideContent(slide_type=ContentType.BULLETS,
                         title="Key Benefits",
                         bullets=[
                             BulletPoint(text="Faster diagnostics", level=0),
                             BulletPoint(text="Reduced admin burden", level=0, bold=True),
                         ]),
            SlideContent(slide_type=ContentType.TWO_COLUMN,
                         title="Pros vs Cons",
                         left_column="Improved accuracy\nLower costs",
                         right_column="Privacy concerns\nRegulatory hurdles"),
            SlideContent(slide_type=ContentType.TABLE,
                         title="Adoption by Department",
                         table=TableData(
                             headers=["Department", "AI Tool", "Adoption %"],
                             rows=[["Radiology", "ImageAI", "78%"],
                                   ["Pharmacy", "RxCheck", "45%"]],
                         )),
            SlideContent(slide_type=ContentType.CLOSING,
                         title="Thank You",
                         subtitle="Questions?",
                         speaker_notes="Open the floor for discussion."),
        ],
    )


# ─────────────────────────────────────────────
# LLM layer
# ─────────────────────────────────────────────

class TestStubLLMClient:
    def test_complete_returns_string(self, stub_llm):
        result = stub_llm.complete("sys", "user")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_complete_json_returns_dict(self, stub_llm):
        data = stub_llm.complete_json("sys", "user")
        assert isinstance(data, dict)
        assert "slides" in data

    def test_stub_slides_have_required_fields(self, stub_llm):
        data = stub_llm.complete_json("sys", "user")
        for slide in data["slides"]:
            assert "slide_type" in slide
            assert "title" in slide


class TestBuildLLMClient:
    def test_disabled_returns_stub(self):
        client = build_llm_client({"provider": "disabled"})
        assert isinstance(client, StubLLMClient)

    def test_unknown_provider_raises(self):
        with pytest.raises(ValueError, match="Unknown LLM provider"):
            build_llm_client({"provider": "nonexistent"})


# ─────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────

class TestModels:
    def test_presentation_request_defaults(self):
        req = PresentationRequest(topic="Test")
        assert req.num_slides == 10
        assert req.tone == "professional"
        assert req.language == "en"

    def test_presentation_request_slide_bounds(self):
        with pytest.raises(Exception):
            PresentationRequest(topic="Test", num_slides=0)
        with pytest.raises(Exception):
            PresentationRequest(topic="Test", num_slides=100)

    def test_bullet_point_defaults(self):
        bp = BulletPoint(text="Hello")
        assert bp.level == 0
        assert bp.bold is False

    def test_table_data_roundtrip(self):
        td = TableData(headers=["A", "B"], rows=[["1", "2"]])
        assert td.headers == ["A", "B"]
        assert td.rows[0] == ["1", "2"]

    def test_content_type_enum_values(self):
        assert ContentType.TITLE_SLIDE.value == "title_slide"
        assert ContentType.BULLETS.value == "bullets"


# ─────────────────────────────────────────────
# Template Analyzer
# ─────────────────────────────────────────────

class TestTemplateAnalyzer:
    def test_analyze_from_presentation(self, blank_prs):
        analyzer = TemplateAnalyzer()
        info = analyzer.analyze_from_presentation(blank_prs)
        assert info.slide_width > 0
        assert info.slide_height > 0
        assert len(info.layouts) > 0

    def test_layouts_have_names(self, template_info):
        for layout in template_info.layouts:
            assert isinstance(layout.name, str)

    def test_layout_placeholder_types(self, template_info):
        for layout in template_info.layouts:
            for ph in layout.placeholders:
                assert isinstance(ph.ph_type, str)


# ─────────────────────────────────────────────
# Layout Selector
# ─────────────────────────────────────────────

class TestLayoutSelector:
    def test_returns_valid_index(self, template_info):
        selector = LayoutSelector(template_info)
        for ct in ContentType:
            slide = SlideContent(slide_type=ct, title="Test")
            idx = selector.select(slide)
            assert 0 <= idx < len(template_info.layouts), \
                f"Index {idx} out of range for {ct}"

    def test_respects_explicit_layout_index(self, template_info):
        selector = LayoutSelector(template_info)
        slide = SlideContent(slide_type=ContentType.CONTENT, title="X", layout_index=0)
        assert selector.select(slide) == 0

    def test_caches_results(self, template_info):
        selector = LayoutSelector(template_info)
        slide = SlideContent(slide_type=ContentType.BULLETS, title="X")
        idx1 = selector.select(slide)
        idx2 = selector.select(slide)
        assert idx1 == idx2


# ─────────────────────────────────────────────
# Slide Populator
# ─────────────────────────────────────────────

class TestSlidePopulator:
    def _make_slide(self, blank_prs, layout_idx=0):
        layout = blank_prs.slide_masters[0].slide_layouts[layout_idx]
        return blank_prs.slides.add_slide(layout)

    def test_populate_title_slide(self, blank_prs):
        from src.pptx.slide_populator import SlidePopulator
        slide = self._make_slide(blank_prs, 0)
        content = SlideContent(slide_type=ContentType.TITLE_SLIDE,
                               title="Hello", subtitle="World")
        pop = SlidePopulator()
        pop.populate(slide, content)   # should not raise

    def test_populate_bullets(self, blank_prs):
        from src.pptx.slide_populator import SlidePopulator
        # Find a layout with body placeholder
        layout_idx = 0
        for i, layout in enumerate(blank_prs.slide_masters[0].slide_layouts):
            if len(list(layout.placeholders)) > 1:
                layout_idx = i
                break
        slide = self._make_slide(blank_prs, layout_idx)
        content = SlideContent(slide_type=ContentType.BULLETS,
                               title="My Bullets",
                               bullets=[BulletPoint(text="Point A"),
                                        BulletPoint(text="Point B", level=1)])
        SlidePopulator().populate(slide, content)

    def test_populate_table(self, blank_prs):
        from src.pptx.slide_populator import SlidePopulator
        slide = self._make_slide(blank_prs, 0)
        content = SlideContent(
            slide_type=ContentType.TABLE,
            title="Data Table",
            table=TableData(headers=["Col1", "Col2"],
                            rows=[["A", "B"], ["C", "D"]]),
        )
        SlidePopulator().populate(slide, content)


# ─────────────────────────────────────────────
# Orchestrator (end-to-end)
# ─────────────────────────────────────────────

class TestOrchestrator:
    def test_full_pipeline_stub(self, sample_request, tmp_path):
        llm = StubLLMClient()
        builder = PresentationBuilder()
        agent = PresentationOrchestrator(llm, builder)
        job = agent.run(sample_request, output_dir=str(tmp_path))
        assert job.status == GenerationStatus.COMPLETE
        assert job.output_path is not None
        assert Path(job.output_path).exists()

    def test_output_is_valid_pptx(self, sample_request, tmp_path):
        from pptx import Presentation
        llm = StubLLMClient()
        agent = PresentationOrchestrator(llm, PresentationBuilder())
        job = agent.run(sample_request, output_dir=str(tmp_path))
        prs = Presentation(job.output_path)
        assert len(prs.slides) > 0

    def test_progress_callback_called(self, sample_request, tmp_path):
        calls = []
        llm = StubLLMClient()
        agent = PresentationOrchestrator(llm, PresentationBuilder())
        agent.run(sample_request, output_dir=str(tmp_path),
                  progress_cb=lambda pct, msg: calls.append(pct))
        assert len(calls) > 0
        assert calls[-1] == 100

    def test_plan_has_correct_slide_count(self, tmp_path):
        req = PresentationRequest(topic="Test", num_slides=3)
        llm = StubLLMClient()
        job = PresentationOrchestrator(llm, PresentationBuilder()).run(req, str(tmp_path))
        # Stub always returns 3 slides
        assert job.plan is not None
        assert len(job.plan.slides) == 3

    def test_builder_uses_supplied_plan(self, sample_plan, tmp_path):
        """Builder can accept a pre-built plan directly (bypassing LLM)."""
        builder = PresentationBuilder()
        path = builder.build(sample_plan, output_dir=str(tmp_path))
        assert Path(path).exists()

    def test_job_log_is_non_empty(self, sample_request, tmp_path):
        llm = StubLLMClient()
        job = PresentationOrchestrator(llm, PresentationBuilder()).run(
            sample_request, output_dir=str(tmp_path))
        assert len(job.log) > 0
